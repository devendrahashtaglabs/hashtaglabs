<?php
@define( 'PARENT_DIR', get_template_directory() );
@define( 'CHILD_DIR', get_stylesheet_directory() );
@define( 'PARENT_URL', get_template_directory_uri() );
@define( 'CHILD_URL', get_stylesheet_directory_uri() );

/*-----------------------------------------------------------------------------------*/
/*	Post Meta Boxes
/*-----------------------------------------------------------------------------------*/
define( 'RWMB_URL', trailingslashit( PARENT_URL . '/inc/meta-box' ) );
define( 'RWMB_DIR', trailingslashit( PARENT_DIR . '/inc/meta-box' ) );
require_once ( RWMB_DIR . 'meta-box.php' );
include_once(PARENT_DIR . '/inc/meta-box/meta-boxes.php');

/*-----------------------------------------------------------------------------------*/
/*	Post Category Meta Class
/*-----------------------------------------------------------------------------------*/
include_once(PARENT_DIR . '/inc/Tax-meta-class/Tax-meta-class.php');
include_once(PARENT_DIR . '/inc/Tax-meta-class/usage.php');

/* change order of text aria in comments form  */
function wpb_move_comment_field_to_bottom( $fields ) {
	$comment_field = $fields['comment'];
	unset( $fields['comment'] );
	$fields['comment'] = $comment_field;
	return $fields;
}

/* register redux theme option */
if ( !class_exists( 'ReduxFramework' ) && file_exists( dirname( __FILE__ ) . '/inc/options/ReduxCore/framework.php' ) ) {
	require_once( dirname( __FILE__ ) . '/inc/options/ReduxCore/framework.php' );
}
if ( !isset( $redux_demo ) && file_exists( dirname( __FILE__ ) . '/inc/options/sample/sample-config.php' ) ) {
	require_once( dirname( __FILE__ ) . '/inc/options/sample/sample-config.php' );
}
add_theme_support( 'post-thumbnails' );
/* include walker class */
include_once(PARENT_DIR . '/inc/walker/bootstrap-walker.php');
/* include Pagination */
include_once(PARENT_DIR . '/inc/pagination/wp_bootstrap_pagination.php');
/* include style or js files */
include_once(PARENT_DIR . '/inc/register_style.php');
/* register menus */
include_once(PARENT_DIR . '/inc/register_menus.php');
/* register menus */
include_once(PARENT_DIR . '/inc/register_sidebar.php');
/* register widgets */
include_once( PARENT_DIR . '/inc/widgets/contact-widget.php' );
include_once( PARENT_DIR . '/inc/widgets/recent-posts.php' );
/* register custom post type */
include_once(PARENT_DIR . '/inc/register_postType.php');
/* register taxonamies of custom post type */
include_once(PARENT_DIR . '/inc/register_taxoNomy.php');
/* add shortcode for custom post type gallery */
//include_once(PARENT_DIR . '/inc/add_shortcode.php');
/* form comments list  */
include_once(PARENT_DIR . '/inc/comments_list.php');