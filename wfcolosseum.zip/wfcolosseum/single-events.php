<?php
/**
 * The Page for our theme.
 *
 * Displays all of the section
 *
 * @package WordPress
 * @subpackage wfcolosseum
 * @since wfcolosseum 1.0.0
 *
 */
?>
<?php global $theme_options; ?>
<?php get_header(); ?>
<!-- slider section -->
<?php get_template_part('sections/slider'); ?>
<section class="event-desc">
	<div class="inner-container container">
   <?php echo do_shortcode( $theme_options['events_booking_form'] ); ?>
   <?php if(have_posts()): while(have_posts()):the_post();
		$similar_events		= get_post_meta( get_the_id(),'wfcolosseum_similar_events',true);
		get_template_part('template-parts/single','post');
		endwhile; endif; ?>
	</div>
</section>
<?php if( !empty( $similar_events ) ) { ?>
<section id="other-rooms">
	<div class="inner-container container">
		<div class="ravis-title">
			<div class="inner-box">
				<div class="title"><?php echo __($theme_options['event_similar_title'],'wfcolosseum'); ?></div>
				<div class="sub-title"><?php echo __($theme_options['event_similar_subTitle'],'wfcolosseum'); ?></div>
			</div>
		</div>
		<div class="room-container clearfix">
		<?php $similar_events = explode(',',$similar_events);
			foreach( $similar_events as $similar_event ):
				$args = array( 
						'post_type' => 'events', 
						//'s' 		=> $similar_event,
						'name' 		=> $similar_event,
						//'tag__in'    => $similar_room,
						//'post__not_in' => array($post->ID),
						);
				$loop = new WP_Query( $args );
				if ( $loop->have_posts() ): 
				  while ( $loop->have_posts() ) {
					$loop->the_post(); 
					get_template_part( "template-parts/similar","posts" );
				} endif; 
			endforeach;
		?>
		</div>
	</div>
</section>
<?php } get_footer(); ?>