<?php
/**
 * The Page for our theme.
 *
 * Displays all of the section
 *
 * @package WordPress
 * @subpackage wfcolosseum
 * @since wfcolosseum 1.0.0
 *
 */
?>
<?php global $theme_options;?>
<?php get_header(); ?>
<!-- slider section -->
<?php get_template_part('sections/banner','page'); ?>
<?php if(have_posts()): while(have_posts()):the_post(); ?>
<section id="welcome-section" class="has-user">
	<div class="inner-container container">
		<?php if( has_post_thumbnail() ){ ?>
		<div class="l-sec col-md-7">
		<?php } else { ?>
		<div class="l-sec col-md-12 col-xs-12 col-lg-12 col-sm-12">
		<?php } ?>
			<div class="ravis-title-t-1">
				<div class="title"><span><?php echo get_post_meta( get_the_ID(), 'wfcolosseum_title', true ); ?></span></div>
				<div class="sub-title"><?php echo get_post_meta( get_the_ID(), 'wfcolosseum_sub_title', true ); ?></div>
			</div>
			<div class="content">
				<?php echo get_the_content(); ?>	
			</div>
		</div>
		<?php if( has_post_thumbnail() ): ?>
		<div class="r-sec col-md-5">
			<div class="user-img-box">
				<div class="inner-box">
					<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>">
				</div>
			</div>
		</div>
		<?php endif; ?>
	</div>
</section>
<?php endwhile; endif; ?>
<?php get_footer(); ?>