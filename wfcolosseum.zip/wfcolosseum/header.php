<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till body
 *
 * @package WordPress
 * @subpackage wfcolosseum
 * @since wf-accent 1.0.0
 *
 */
?>
<!DOCTYPE html>
<html<?php language_attributes(); ?>>
<?php global $theme_options; ?>
<head>
    <title>
        <?php
        if ( is_category() ) {
            echo __('Category Archive for &quot;', 'wf-accent'); single_cat_title(); echo __('&quot; | ', 'wf-accent'); bloginfo( 'name' );
        } elseif ( is_tag() ) {
            echo __('Tag Archive for &quot;', 'wf-accent'); single_tag_title(); echo __('&quot; | ', 'wf-accent'); bloginfo( 'name' );
        } elseif ( is_archive() ) {
            wp_title(''); echo __(' Archive | ', 'wf-accent'); bloginfo( 'name' );
        } elseif ( is_search() ) {
            echo __('Search for &quot;', 'wf-accent').wp_specialchars($s).__('&quot; | ', 'wf-accent'); bloginfo( 'name' );
        } elseif ( is_home() || is_front_page()) {
            bloginfo( 'name' ); echo ' | '; bloginfo( 'description' );
        }  elseif ( is_404() ) {
            echo __('Error 404 Not Found | ', 'wf-accent'); bloginfo( 'name' );
        } elseif ( is_single() ) {
            wp_title('');
        } else {
            echo wp_title( ' | ', false, 'right' ); bloginfo( 'name' );
        } 
    ?>
    </title>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="format-detection" content="telephone=no"/>
	<?php if (!empty($theme_options['header-metas'])) { ?>
	<?php echo $theme_options['header-metas']; ?>
	<?php } ?>
	<?php if ($theme_options['responsive']){ ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no">
	<?php } ?>
	<?php if (!empty($theme_options['favicon']['url'])) { ?>
		<link rel="icon" href="<?php echo $theme_options['favicon']['url']; ?>" type="image/x-icon" />
		<link rel="shortcut icon" href="<?php echo $theme_options['favicon']['url']; ?>" type="image/x-icon" />
		<link rel="apple-touch-icon" href="<?php echo $theme_options['favicon']['url']; ?>"/>
	<?php  } else { ?>
		<link rel="icon" href="<?php bloginfo( 'template_url' ); ?>/images/logo.png" type="image/x-icon" />
		<link rel="shortcut icon" href="<?php bloginfo( 'template_url' ); ?>/images/logo.png" type="image/x-icon" />
		<link rel="apple-touch-icon" href="<?php bloginfo( 'template_url' ); ?>/images/logo.png"/>
	<?php } ?>
    <link rel="profile" href="http://gmpg.org/xfn/11" />
    <meta http-equiv="content-type" content="<?php bloginfo('html_type') ?>; charset=<?php bloginfo('charset') ?>" />
    <!--[if lt IE 7 ]><html class="ie ie6" <?php language_attributes();?>> <![endif]-->
    <!--[if IE 7 ]><html class="ie ie7" <?php language_attributes();?>> <![endif]-->
    <!--[if IE 8 ]><html class="ie ie8" <?php language_attributes();?>> <![endif]-->
    <!--[if IE 9 ]><html class="ie ie9" <?php language_attributes();?>> <![endif]-->
    <!--[if (gt IE 9)|!(IE)]><html <?php language_attributes();?>><![endif]-->
    <!--[if !IE]><html <?php language_attributes();?>><![endif]-->
    <!--[if lt IE 9]>
    <div style=' clear: both; text-align:center; position: relative;'>
        <a href="http://windows.microsoft.com/en-US/internet-explorer/..">
            <img src="<?php bloginfo( 'template_url' ); ?>/images/ie8-panel/warning_bar_0000_us.jpg" border="0" height="42" width="820"
                 alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."/>
        </a>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script>
    <![endif]-->
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
    <link rel="alternate" type="application/atom+xml" title="<?php bloginfo( 'name' ); ?>" href="<?php bloginfo( 'atom_url' ); ?>" />
	<?php if(is_search()) { ?>
		<meta name="robots" content="noindex, nofollow" /> 
	<?php }?>
	<?php if(is_archive() && !is_category()){ ?>
		<meta name="robots" content="noindex" />
	<?php } ?>
	<style>
	<?php if (!empty($theme_options['custom-css'])) { ?>
	<?php echo $theme_options['custom-css']; ?>
	<?php } ?>
	</style>
	<?php //get_template_part('templates/page','style'); ?>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<div class="main-wrapper">
		<!-- Header Section -->
		<header id="main-header">
			<div class="inner-container container">
				<div class="l-sec col-xs-8 col-sm-6 col-md-3">
					<a href="<?php echo home_url(); ?>" id="t-logo">
						<?php if( $theme_options['select_opt'] == "text" ):?>
						<span class="title"><?php echo __($theme_options['main_title'],'wfcolosseum'); ?></span>
						<span class="desc"><?php echo __($theme_options['main_subtitle'],'wfcolosseum'); ?></span>
						<?php else: ?>
						<img src="<?php echo $theme_options['logo']['url']; ?>" alt="blog logo" class="img-responsive center-block"/>
						<?php endif;?>
					</a>
				</div>
				<div class="r-sec col-xs-4 col-sm-6 col-md-9">
					<nav id="main-menu">
					<?php if ( has_nav_menu( 'header' ) ):
								wp_nav_menu( 
									$args = array( 
											'container_class'     => '',
											'theme_location'     => 'header', 
											'menu_class'        => 'list-inline',
											'walker'             => new wp_bootstrap_navwalker
										)
								);
							else: ?>
						<ul class="list-inline">
							<li class="active">
								<a href="<?php echo home_url(); ?>">Home</a>
							</li>
						</ul>
						<?php endif; ?>
					</nav>
					<div id="main-menu-handle" class="ravis-btn btn-type-2"><i class="fa fa-bars"></i><i class="fa fa-close"></i></div><!-- Mobile Menu handle -->
					<a href="pages/booking.html" id="header-book-bow" class="ravis-btn btn-type-2"><span>Book Bow</span> <i class="fa fa-calendar"></i></a>
				</div>
			</div>
			<div id="mobile-menu-container"></div>
		</header>