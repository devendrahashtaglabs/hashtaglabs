<?php
/**
 * The Page for our theme.
 *
 * Displays all of the section
 *
 * @package WordPress
 * @subpackage wfcolosseum
 * @since wfcolosseum 1.0.0
 *
 */
?>
<aside id="sidebar" class="col-md-4">
<?php if ( is_active_sidebar( 'right_sidebar' ) ) : ?>
	<?php dynamic_sidebar('right_sidebar'); ?>
<?php endif; ?>
</aside>