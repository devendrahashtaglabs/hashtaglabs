<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package wfcolosseum
 */
?>
<?php get_header(); ?>
<!-- slider section-->
<?php get_template_part( "sections/slider" ); ?>
<!--Main Booking form-->
<?php //get_template_part( "sections/availability", "form" ); ?>
<!--Welcome Section-->
<?php get_template_part( "sections/welcome" ); ?>
<!--Luxury Room Section-->
<?php get_template_part( "sections/rooms" ); ?>
<!-- Gallery -->
<?php get_template_part( "sections/gallery","top" ); ?>
<?php get_template_part( "sections/gallery" ); ?>
<!-- Testimonials Section -->
<?php get_template_part( "sections/testimonials" ); ?>
<!-- Special Offers -->
<?php get_template_part( "sections/offers" ); ?>
<?php get_footer(); ?>