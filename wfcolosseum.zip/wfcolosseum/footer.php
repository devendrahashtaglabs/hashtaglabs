<?php
/**
 * The Footer for our theme.
 *
 * Displays all of the <footer> section and everything up till body
 *
 * @package WordPress
 * @subpackage wfcolosseum
 * @since wfcolosseum 1.0.0
 * 
 */
?>
<?php global $theme_options;  ?>
<footer id="main-footer">
	<div class="inner-container container">
		<div class="t-sec clearfix">
			<?php dynamic_sidebar('footer_widget_area'); ?>
		</div>
		<div class="b-sec clearfix">
			<div class="copy-right">
				With <i class="fa fa-heart"></i> by 
				<a href="<?php echo home_url("/"); ?>" target="_blank">
					<?php echo bloginfo("name"); ?>
				</a> <?php echo __($theme_options['footer-copyright'],'wfcolosseum');?>
			</div>
			<ul class="social-icons list-inline">
				<?php if( !empty( $theme_options['facebook'] ) ) { ?>
				<li>
					<a target="_blank" href="<?php echo $theme_options['facebook'];?>">
						<i class="fa fa-facebook"></i>
					</a>
				</li>
				<?php } if( !empty( $theme_options['twitter'] ) ) { ?>
				<li>
					<a target="_blank" href="<?php echo $theme_options['twitter'];?>">
						<i class="fa fa-twitter"></i>
					</a>
				</li>
				<?php } if( !empty( $theme_options['google_plus'] ) ) { ?>
				<li>
					<a target="_blank" href="<?php echo $theme_options['google_plus'];?>">
						<i class="fa fa-google-plus"></i>
					</a>
				</li>
				<?php } if( !empty( $theme_options['youtube'] ) ) { ?>
				<li>
					<a target="_blank" href="<?php echo $theme_options['youtube'];?>">
						<i class="fa fa fa-youtube"></i>
					</a>
				</li>
				<?php } ?>
			</ul>
		</div>
	</div>
</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>