<?php
/**
 * The Page for our theme.
 *
 * Displays all of the section
 *
 * @package WordPress
 * @subpackage wfcolosseum
 * @since wfcolosseum 1.0.0
 *
 */
?>
<?php global $theme_options; ?>
<?php get_header(); ?>
<!-- slider section -->
<?php get_template_part('sections/banner','404'); ?>	
<?php get_footer(); ?>