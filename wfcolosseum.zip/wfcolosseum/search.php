<?php
/**
 * The Page for our theme.
 *
 * Displays all of the section
 *
 * @package WordPress
 * @subpackage wfcolosseum
 * @since wfcolosseum 1.0.0
 *
 */
?>
<?php global $theme_options; ?>
<?php get_header(); ?>
<!-- slider section -->
<?php get_template_part('sections/banner','404'); ?>
<section class="welcome welcome_section">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 text-center">
				<h2 class="hvr-underline-from-center wow zoomIn" data-wow-duration="2s" data-wow-delay="0.3s"><?php printf( __( 'Search Results for: %s', 'wf-accent' ), '<span>' . esc_html( get_search_query() ) . '</span>' ); ?></h2>
			</div>
		</div>
	</div>
</section>
<section id="blog-section">
	<div class="inner-container container">
		<div class="post-main-container clearfix">
		  <?php if ( have_posts() ) : ?>
		<?php  while ( have_posts() ) : the_post(); ?>
		<?php	get_template_part( 'template-parts/content', 'search' ); ?>
		<?php	endwhile;
			the_posts_pagination( array(
				'prev_text'          => __( 'Previous page', 'wf-accent' ),
				'next_text'          => __( 'Next page', 'wf-accent' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'wf-accent' ) . ' </span>',
			) );
		?>
		<?php else : ?>
		  <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12 text-center">
		<?php get_template_part( 'template-parts/content', 'none' ); ?>
		   </div>
		<?php 	endif; ?>
	</div>
</div>
</section>		
<?php get_footer(); ?>