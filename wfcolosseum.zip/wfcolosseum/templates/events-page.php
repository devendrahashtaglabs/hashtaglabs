<?php
/**
 * The Page for our theme.
 *
 * Displays all of the section
 *
 * @package WordPress
 * @subpackage wfcolosseum
 * @since wfcolosseum 1.0.0
 *
 * Template Name: Events Page
 */
?>
<?php global $theme_options;?>
<?php get_header(); ?>
<?php get_template_part('sections/banner','page'); ?>
<?php $paged = (get_query_var('paged')) ? get_query_var('paged') : 1; ?>
<section id="upcoming-events">
	<div class="inner-container container">
		<div class="ravis-title">
			<div class="inner-box">
				<div class="title">Upcoming Events</div>
				<div class="sub-title">We proudly host some international events</div>
			</div>
		</div>

		<div class="event-container">
			<div class="sort-section">
				<div class="sort-section-container">
					<div class="sort-handle">Filters</div>
					<ul class="list-inline">
						<?php $terms = get_terms( array(
													'taxonomy' => 'eventsType',
													'hide_empty' => false,
												) ); 
						?>
						<li><a href="#" data-filter="*" class="active">All</a></li>
						<?php foreach( $terms as $term ) : ?>
						<li>
							<a href="#" data-filter=".<?php echo strtolower( $term->name ); ?>"><?php echo $term->name; ?></a>
						</li>
						<?php endforeach; ?>
					</ul>
				</div>
			</div>
			<ul class="event-main-box clearfix">
			<?php $args = array(
							'post_type' 	=> 'events', 
							'posts_per_page'=> -1,
							'orderby'		=> 'wfcolosseum_scheduled_post',
							'order' 		=> 'ASC',
							'meta_query'	=> array( 
													array(
														'key' 	=> 'wfcolosseum_scheduled_post',
														'value' => date("Y-m-d"),
														'compare'=> '>=',
														'type' 	=> 'DATE'
													)
												)
							);
				$loop = new WP_Query( $args );
				while ( $loop->have_posts() ) : $loop->the_post(); 
				if ( has_post_thumbnail() ) : 
				$categories = get_the_terms( get_the_ID(), 'eventsType' );
				$terms	 = array();
				foreach( $categories as $category ):
				$terms[] = $category->name;
				endforeach;
				$term = implode( " ", $terms );
			 ?>
				<li class="item col-xs-6 col-md-4 <?php echo strtolower( $term ); ?>">
					<figure>
						<a href="<?php the_permalink(); ?>" class="more-details">
							<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>"/>
						</a>
						<figcaption>
							<a href="<?php the_permalink(); ?>">
								<span class="title-box">
									<span class="title"><?php the_title(); ?></span>
									<span class="sub-title"><?php echo get_post_meta(get_the_ID(),'wfcolosseum_sub_title',true); ?></span>
								</span>
								<span class="desc">
									<?php echo substr(get_the_excerpt(), 0,50)."…"; ?>
								</span>
							</a>
						</figcaption>
					</figure>
				</li>
				<?php endif; endwhile; wp_reset_query(); ?>
			</ul>
		</div>
	</div>
</section>
<!-- End of Upcoming Events -->

<!-- Past Events -->
<section id="past-events">
	<div class="inner-container container">

		<div class="ravis-title">
			<div class="inner-box">
				<div class="title">Past Events</div>
				<div class="sub-title">Some of our past events is listed here</div>
			</div>
		</div>

		<div class="event-container">
			<ul class="event-main-box clearfix">
			<?php $args = array(
							'post_type' 	=> 'events', 
							'orderby'		=> 'wfcolosseum_scheduled_post',
							'order' 		=> 'ASC',
							'posts_per_page'=> get_option('posts_per_page'),
							'paged'         => $paged, 
							'meta_query'	=> array( 
													array(
														'key' 	=> 'wfcolosseum_scheduled_post',
														'value' => date("Y-m-d"),
														'compare'=> '<',
														'type' 	=> 'DATE'
													)
												)
							);
				$loop = new WP_Query( $args );
				while ( $loop->have_posts() ) : $loop->the_post(); 
				if ( has_post_thumbnail() ) : 
				?>
				<li class="item col-xs-6 col-md-4">
					<figure>
						<a href="<?php the_permalink(); ?>" class="more-details">
							<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>"/>
						</a>
						<figcaption>
							<a href="<?php the_permalink(); ?>">
								<span class="title-box">
									<span class="title"><?php the_title(); ?></span>
									<span class="sub-title"><?php echo get_post_meta(get_the_ID(),'wfcolosseum_sub_title',true); ?></span>
								</span>
								<span class="desc">
									<?php echo substr(get_the_excerpt(), 0,50)."…"; ?>
								</span>
							</a>
						</figcaption>
					</figure>
				</li>
				<?php endif; endwhile; wp_reset_query(); ?>
			</ul>
		</div>
		<?php if ( function_exists('wp_bootstrap_pagination') ) :
						 wp_bootstrap_pagination(array('custom_query' => $loop)); ?>
		<?php endif; ?>
	</div>
</section>
<?php get_footer(); ?>