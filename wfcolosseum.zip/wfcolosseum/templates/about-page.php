<?php
/**
 * The Page for our theme.
 *
 * Displays all of the section
 *
 * @package WordPress
 * @subpackage wfcolosseum
 * @since wfcolosseum 1.0.0
 *
 * Template Name: About Page
 */
?>
<?php global $theme_options;?>
<?php get_header(); ?>
<!-- slider section -->
<?php get_template_part('sections/banner','page'); ?>
<?php get_template_part('sections/welcome','about'); ?>
<?php get_template_part('sections/video','tour'); ?>
<!-- End of Video Tour -->

<!-- Our History -->
<section id="history-section">
	<div class="inner-container container">
		<div class="ravis-title-t-2">
			<div class="title">
				<span><?php echo __($theme_options['history_title'],'wfcolosseum');?></span>
			</div>
			<div class="sub-title">
				<?php echo __($theme_options['history_subTitle'],'wfcolosseum');?>
			</div>
		</div>

		<div class="desc">
			<?php echo __($theme_options['history_description'],'wfcolosseum');?>
		</div>

		<!-- History Main Container -->
		<div class="history-timeline clearfix">
			<?php $slides = $theme_options['history-slides'];
			
			/*** sorting array to desc by time ****/
				$time = array();
				foreach ($slides as $key => $row) {
					$time[$key] = $row['url'];
				}
				array_multisort($time, SORT_DESC, $slides);
			/*** sorting array to desc by time ****/
			
			$counter = '1';
			foreach( $slides as $slide ):
			$animation  = ( $counter/2 == 0 )?"fadeInRight":"fadeInLeft";
			?>
			<div class="history-boxes col-md-6 col-xs-6 animated-box" data-animation="<?php echo $animation; ?>">
				<div class="history-boxes-inner">
					<i><?php echo __($slide['url'],'wfcolosseum');?></i>
					<h5><?php echo __($slide['title'],'wfcolosseum');?></h5>
					<div class="history-content">
						<?php echo __($slide['description'],'wfcolosseum');?>
					</div>
				</div>
			</div>
			<?php $counter++; endforeach ?>
		</div>
	</div>
</section>
<?php get_footer(); ?>