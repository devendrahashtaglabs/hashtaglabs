<?php
/**
 * The Page for our theme.
 *
 * Displays all of the section
 *
 * @package WordPress
 * @subpackage wfcolosseum
 * @since wfcolosseum 1.0.0
 *
 * Template Name: Room Page
 */
?>
<?php global $theme_options;?>
<?php get_header(); ?>
<!-- slider section -->
<?php get_template_part('sections/banner','page'); ?>
<section id="rooms-section">
	<div class="inner-container container">
		<div class="ravis-title-t-2">
			<div class="title">
				<span><?php echo __($theme_options['roomsTitle'],'wfcolosseum');?></span>
			</div>
		</div>
		<div class="desc">
			<?php echo __($theme_options['rooms_description'],'wfcolosseum');?>
		</div>

		<div class="room-container clearfix">
			<?php $latest_posts = get_terms( 'roomsType' );
 				if ( $latest_posts ) { 
					foreach ( $latest_posts as $post ):
					$album_image = get_term_meta( $post->term_id,'album_image',true);
	 				$starting_price= get_term_meta( $post->term_id,'starting_price',true);
			?>
			<div class="room-box col-xs-6 col-md-4 animated-box" data-animation="fadeInUp">
				<div class="inner-box" data-bg-img="<?php echo ( !empty( $album_image ) )?$album_image['url']:''; ?>">
					<a href="<?php echo home_url('/wfrooms/').$post->slug; ?>" class="more-info"></a>
					<div class="caption">
						<div class="title"><?php echo __($post->name,'wfcolosseum'); ?></div>
						<div class="price">
							<div class="title">Starting from :</div>
							<div class="value"><?php echo __($starting_price,'wfcolosseum'); ?></div>
						</div>
						<div class="desc">
							<div class="inner-box">
								<?php echo __($post->description,'wfcolosseum'); ?>
							</div>
						</div>
					</div>

				</div>
			</div>
			<?php endforeach; } ?>
		</div>
		<?php if ( function_exists('wp_bootstrap_pagination') ) :
						 wp_bootstrap_pagination(); ?>
		<?php endif; ?>
	</div>
</section>
<?php get_footer(); ?>