<?php
/**
 * The Page for our theme.
 *
 * Displays all of the section
 *
 * @package WordPress
 * @subpackage wfcolosseum
 * @since wfcolosseum 1.0.0
 *
 */
?>
<?php global $theme_options; ?>
<?php get_header(); ?>
<!-- slider section -->
<?php get_template_part('sections/slider'); ?>
<section id="blog-section">
	<div class="inner-container container">
		<div class="post-main-container col-md-8">
		<?php if(have_posts()): while(have_posts()):the_post(); ?>
			<div class="post-box">
				<?php if( has_post_thumbnail() ): ?>
				<a class="post-img-box" href="#">
					<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="post-img img-responsive center-block">
				</a>
				<?php endif; ?>
				<div class="post-b-sec">
					<div class="post-title-box">
						<a href="<?php the_permalink(); ?>" class="post-title"><?php the_title(); ?></a>
					</div>
					<div class="post-meta clearfix">
						<div class="post-date"><i class="fa fa-calendar"></i><?php the_time('d M, Y'); ?></div>
						<div class="post-author"><i class="fa fa-edit"></i> By : <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' )); ?>"><?php the_author(); ?></a></div>
						<div class="post-comment"><i class="fa fa-comments-o"></i><a href="<?php comments_link(); ?>"><?php comments_popup_link( 'No comments yet', '1 comment', '% comments', 'comments-link', 'Comments are off for this post');	?></a></div>
					</div>
					<div class="post-desc">
						<?php the_excerpt(); ?>
					</div>
					<?php if(has_tag()) { ?>
					<div class="post-tags">
					<?php the_tags('','', '' ); ?> 
					</div>
					<?php } ?>
				</div>
				<?php comments_template(); ?>
			</div>
		<?php endwhile; endif; ?>
		</div>
		<?php get_sidebar(); ?>
	</div>
</section>
<?php get_footer(); ?>