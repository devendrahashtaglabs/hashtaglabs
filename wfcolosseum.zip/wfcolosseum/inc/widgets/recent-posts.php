<?php
class Realty_Widget extends WP_Widget{
function __construct() {
	parent::__construct(
		'realty_widget', // Base ID
		'Latest Posts', // Name
		array('description' => __( 'Displays your latest posts. Outputs the  title  per post'))
	   );
}
function update($new_instance, $old_instance) {
	$instance = $old_instance;
	$instance['title'] = strip_tags($new_instance['title']);
	$instance['numberOfPosts'] = strip_tags($new_instance['numberOfPosts']);
	return $instance;
}
function form($instance) {
	if( $instance) {
		$title = esc_attr($instance['title']);
		$numberOfPosts = esc_attr($instance['numberOfPosts']);
	} else {
		$title = '';
		$numberOfPosts = '';
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'realty_widget'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('numberOfPosts'); ?>"><?php _e('Number of listings', 'wf_contact'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('numberOfPosts'); ?>" name="<?php echo $this->get_field_name('numberOfPosts'); ?>" type="text" value="<?php echo $numberOfPosts; ?>" />
		</p>
	<?php
	}
function widget($args, $instance) {
	extract( $args );
	$title = apply_filters('widget_title', $instance['title']);
	$numberOfPosts = $instance['numberOfPosts'];
	echo $before_widget;
	if ( $title ) {
		echo $before_title . $title . $after_title;
	}
	$this->getRealtyListings($numberOfPosts);
	echo $after_widget;
}
function getRealtyListings($numberOfPosts) { 
	global $post;
	$args = array(
		  	'numberposts' => $numberOfPosts,
		  	'post_type'   => 'post'
		);
	$latest_posts = get_posts( $args );
	if ( $latest_posts ) { ?>
	<div class="widget-content latest-posts">
		<ul>
		<?php  foreach ( $latest_posts as $post ) {
        		setup_postdata( $post );  ?>
			<li class="clearfix">
				<div class="row">
					<?php if( has_post_thumbnail() ){ ?>
					<div class="img-container col-xs-4 col-md-4 col-lg-4 col-sm-4">
						 <a href="<?php the_permalink(); ?>">
						 <img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive">
						 </a>
					 </div>
					<div class="desc-box col-xs-8 col-md-8 col-lg-8 col-sm-8">
					<?php } else { ?>
					<div class="desc-box col-xs-12 col-md-12 col-lg-12 col-sm-12">
					<?php } ?>
					 <a href="<?php the_permalink(); ?>" class="title"><?php the_title(); ?></a>
						 <div class="desc">
							 <?php echo( get_the_excerpt() ); ?>
						 </div>
					 <a href="<?php the_permalink(); ?>" class="read-more">Read More</a>
					</div>
				</div>
			</li> 
		<?php } ?>
		</ul>
	</div>
<?php 
	}else{
		echo '<p style="padding:25px;">No listing found</p>';
	}
}
 
} 
register_widget('Realty_Widget');
?>