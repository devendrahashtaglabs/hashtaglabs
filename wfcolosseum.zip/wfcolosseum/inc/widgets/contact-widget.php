<?php
class Wf_contact extends WP_Widget{
function __construct() {
	parent::__construct(
		'wf_contact', // Base ID
		'Contact', // Name
		array('description' => __( 'Display your Contact Details'))
	   );
}
function update( $new_instance , $old_instance ) {
	$instance = $old_instance;
	$instance['title'] 		= strip_tags( $new_instance['title'] );
	$instance['email'] 		= strip_tags( $new_instance['email'] );
	$instance['contact_no'] = strip_tags( $new_instance['contact_no'] );
	$instance['address'] 	= strip_tags( $new_instance['address'] );
	return $instance;
}
function form($instance) {
	
    $title 		= ! empty( $instance['title'] ) ? $instance['title'] : '';
    $email 		= ! empty( $instance['email'] ) ? $instance['email'] : '';
    $contact_no = ! empty( $instance['contact_no'] ) ? $instance['contact_no'] : '';
    $address 	= ! empty( $instance['address'] ) ? $instance['address'] : '';
	?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'wf_contact'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('email'); ?>"><?php _e('Email', 'wf_contact'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('email'); ?>" name="<?php echo $this->get_field_name('email'); ?>" type="email" value="<?php echo $email; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('contact_no'); ?>"><?php _e('Contact No', 'wf_contact'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('contact_no'); ?>" name="<?php echo $this->get_field_name('contact_no'); ?>" type="text" value="<?php echo $contact_no; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_name( 'address' ); ?>"><?php _e( 'Address:' ); ?></label>
			<textarea class="widefat" id="<?php echo $this->get_field_id( 'address' ); ?>" name="<?php echo $this->get_field_name( 'address' ); ?>" type="text" rows="5" cols="10" ><?php echo esc_attr( $address ); ?></textarea>
    	</p>
	<?php
	}
function widget( $args , $instance ) {
	extract( $args );
	$title 		= apply_filters('widget_title', $instance['title']);
	$email 		= $instance['email'];
	$contact_no	= $instance['contact_no'];
	$address 	= $instance['address'];
	echo $before_widget;
	if ( $title ) {
		echo $before_title . $title . $after_title;
	}
	$content	= array(
					"email"			=> $email,
					"contact_no"	=> $contact_no,
					"address"		=> $address
					);
	$this->getContactform( $content );
	echo $after_widget;
}
function getContactform( $content = array() ) { 
	global $post;
    $email 			= $content['email'];
    $contact_no 	= $content['contact_no'];
    $address 		= $content['address'];
	$widgetContent  = "<div class='widget-content contact'><ul class='contact-info'>";
		if ( !empty( $contact_no ) ) {
			$widgetContent 	.= "<li><i class='fa fa-home'></i> $address </li>";
		}
		if ( !empty( $email ) ) {
			$widgetContent 	.= "<li><i class='fa fa-phone'></i> $contact_no </li>";
		}
		if ( !empty( $address ) ) {
			$widgetContent 	.= "<li><i class='fa fa-envelope'></i> $email </li>";
		}
	$widgetContent  .= "</ul></div>";
	echo $widgetContent;
}
 
} //end class Wf_contact
register_widget('Wf_contact');
?>