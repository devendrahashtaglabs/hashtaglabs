<?php
/**
*
* excerpt lenght
*
**/
function my_excerpt_length($length) {
return 40;
}
add_filter('excerpt_length', 'my_excerpt_length');
/**
*
* register custom widgits
*
**/
add_theme_support('post-thumbnails');
function create_posttype() {
	register_post_type( 'gallery',
		array(
			'labels' => array(
				'name' => __( 'Gallery' ),
				'singular_name' => __( 'gallery' )
			),
			'public' => true,
			'has_archive' => true,
			'supports' => array( 'title','editor', 'author', 'thumbnail' ,'headway-seo' ),
        	'show_ui' => true,
			'rewrite' => array('slug' => 'wfgallery'),
		)
	);
	register_post_type( 'rooms',
		array(
			'labels' => array(
				'name' => __( 'Rooms' ),
				'singular_name' => __( 'Room' )
			),
			'public' => true,
			'has_archive' => true,
			'supports' => array( 'title', 'editor', 'author', 'thumbnail' ,'headway-seo' ),
        	'show_ui' => true,
			'rewrite' => array('slug' => 'wfrooms'),
		)
	);
	register_post_type( 'offers',
		array(
			'labels' => array(
				'name' => __( 'Offers' ),
				'singular_name' => __( 'Offer' )
			),
			'public' => true,
			'has_archive' => true,
			'supports' => array( 'title', 'editor', 'author', 'thumbnail' ,'headway-seo' ),
        	'show_ui' => true,
			'rewrite' => array('slug' => 'wfoffers'),
		)
	);
	register_post_type( 'events',
		array(
			'labels' => array(
				'name' => __( 'Events' ),
				'singular_name' => __( 'Event' )
			),
			'public' => true,
			'has_archive' => true,
			'supports' => array( 'title', 'editor', 'author', 'thumbnail' ,'headway-seo' ),
        	'show_ui' => true,
			'rewrite' => array('slug' => 'wfevents'),
		)
	);
}
add_action( 'init', 'create_posttype' );
?>