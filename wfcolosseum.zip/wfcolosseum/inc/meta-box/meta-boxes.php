<?php
/**
 * Registering meta boxes
 *
 * All the definitions of meta boxes are listed below with comments.
 * Please read them CAREFULLY.
 *
 * You also should read the changelog to know what has been changed before updating.
 *
 * For more information, please visit:
 * @link http://www.deluxeblogtips.com/meta-box/
 */
add_filter( 'rwmb_meta_boxes', 'wf_jg_register_meta_boxes' );
/**
 * Register meta boxes
 *
 * @return void
 */
function wf_jg_register_meta_boxes( $meta_boxes )
{
	/**
	 * Prefix of meta keys (optional)
	 * Use underscore (_) at the beginning to make keys hidden
	 * Alt.: You also can make prefix empty to disable it
	 */
	// Better has an underscore as last sign
	$prefix = 'wfcolosseum_';
	$meta_boxes[] = array(
		'title' => __( 'Meta Information', 'wfjg' ),
		'pages' => array( 'page' ),
		'context'  => 'normal',
		'fields' => array(
			array(
				'name' 	 		=> __( 'Title', 'rwmb' ),
				'id'    		=> "{$prefix}title",
				'desc'  		=> __( 'Add Title here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'Title', 'rwmb' ),
			),
			array(
				'name' 	 		=> __( 'Sub Title', 'rwmb' ),
				'id'    		=> "{$prefix}sub_title",
				'desc'  		=> __( 'Add Sub Title here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'Sub Title', 'rwmb' ),
			),
			array(
				'name' => __( 'Page Banner', 'rwmb' ),
				'id'   => "{$prefix}banner",
				'type' => 'image',
				'clone'=> false
			),
		)
	);
	$meta_boxes[] = array(
		'title' => __( 'Meta Information', 'wfjg' ),
		'pages' => array( 'events' ),
		'context'  => 'normal',
		'fields' => array(
		    array(
				'name' 	 		=> __( 'Sub Title', 'rwmb' ),
				'id'    		=> "{$prefix}sub_title",
				'desc'  		=> __( 'Add Sub Title here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'Sub Title', 'rwmb' ),
			),
			array(
				'name'          => __( 'Add Schedule Date Here', 'rwmb' ),
				'id'            => "{$prefix}scheduled_post",
				'type'          => 'date',
				'desc'  		=> __( 'Add Schedule Date here', 'rwmb' ),
			),
		    array(
				'name' 	 		=> __( 'Similar Events', 'rwmb' ),
				'id'    		=> "{$prefix}similar_events",
				'desc'  		=> __( 'Add similar events posts with comma separated values here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'Similar Events', 'rwmb' ),
			),
		)
	);
	$meta_boxes[] = array(
		'title' => __( 'Meta Information', 'wfjg' ),
		'pages' => array( 'rooms' ),
		'context'  => 'normal',
		'fields' => array(
		    array(
				'name' 	 		=> __( 'Price', 'rwmb' ),
				'id'    		=> "{$prefix}room_price",
				'desc'  		=> __( 'Add Price here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'Price', 'rwmb' ),
			),
		    array(
				'name' 	 		=> __( 'Similar Rooms', 'rwmb' ),
				'id'    		=> "{$prefix}similar_rooms",
				'desc'  		=> __( 'Add similar rooms posts with comma separated values here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'Similar Rooms', 'rwmb' ),
			),
			array(
				'name' 	 		=> __( 'Breakfast Info', 'rwmb' ),
				'id'    		=> "{$prefix}breakfast_info",
				'desc'  		=> __( 'Add Breakfast Info here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'Breakfast Info', 'rwmb' ),
			),
		   array(
				'name' 	 		=> __( 'Room Size', 'rwmb' ),
				'id'    		=> "{$prefix}room_size",
				'desc'  		=> __( 'Add Room Size here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'Room Size', 'rwmb' ),
			),
		    array(
				'name' 	 		=> __( 'Max People Info', 'rwmb' ),
				'id'    		=> "{$prefix}max_people",
				'desc'  		=> __( 'Add Max People Info here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'Max People Info', 'rwmb' ),
			),
		   array(
				'name' 	 		=> __( 'Facilities', 'rwmb' ),
				'id'    		=> "{$prefix}facilities",
				'desc'  		=> __( 'Add facilities with comma separated values here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'Facilities', 'rwmb' ),
			),
		  array(
				'name' => __( 'Services', 'rwmb' ),
				'id'   => "{$prefix}services",
				'type' => 'checkbox_list',
				'options' => array(
					'hotel-tv'				=> __( 'Hotel TV', 'rwmb' ),
					'towel-on-hanger' 	  	=> __( 'Clothes with Hanger', 'rwmb' ),
					'swimming-pool-sign' 	=> __( 'Swimming Pool', 'rwmb' ),
					'surveillance-camera'   => __( 'CCTV Camera', 'rwmb' ),
					'hotel-left-luggage'    => __( 'Hotel Left', 'rwmb' ),
					'fast-food-burger-and-drink'=> __( 'Fast Food & Drink', 'rwmb' ),
				),
			),
		  array(
				'name' 	 		=> __( 'Rating Title', 'rwmb' ),
				'id'    		=> "{$prefix}rating_title",
				'desc'  		=> __( 'Add Rating Title here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'Rating Title', 'rwmb' ),
			),
		  array(
				'name' 	 		=> __( 'Rating Sub Title', 'rwmb' ),
				'id'    		=> "{$prefix}rating_subTitle",
				'desc'  		=> __( 'Add Rating Sub Title here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'Rating Sub Title', 'rwmb' ),
			),
		  array(
				'name' 	 		=> __( 'Overall Rating', 'rwmb' ),
				'id'    		=> "{$prefix}overall_rating",
				'desc'  		=> __( 'Add Overall Rating here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'Overall Rating', 'rwmb' ),
			),
		  array(
				'name' 	 		=> __( 'Cleanliness Rating', 'rwmb' ),
				'id'    		=> "{$prefix}cleanliness_rating",
				'desc'  		=> __( 'Add Cleanliness Rating here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'Cleanliness Rating', 'rwmb' ),
			),
		   array(
				'name' 	 		=> __( 'Value Rating', 'rwmb' ),
				'id'    		=> "{$prefix}value_rating",
				'desc'  		=> __( 'Add Value Rating here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'Value Rating', 'rwmb' ),
			),
		  array(
				'name' 	 		=> __( 'View Rating', 'rwmb' ),
				'id'    		=> "{$prefix}view_rating",
				'desc'  		=> __( 'Add View Rating here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'View Rating', 'rwmb' ),
			),
		   array(
				'name' 	 		=> __( 'Services Rating', 'rwmb' ),
				'id'    		=> "{$prefix}services_rating",
				'desc'  		=> __( 'Add Services Rating here', 'rwmb' ),
				'type'  		=> 'text',
				'placeholder'	=> __( 'Services Rating', 'rwmb' ),
			),
		)
	);
	return $meta_boxes;
}