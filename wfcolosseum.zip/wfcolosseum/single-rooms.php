<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package wfcolosseum
 */
?>
<?php global $theme_options; ?>
<?php get_header(); ?>
<!-- slider section-->
<?php get_template_part( "sections/slider" ); ?>
<section class="room-desc">
	<?php if(have_posts()): while(have_posts()):the_post();
	    $room_price			= get_post_meta( get_the_id(),'wfcolosseum_room_price',true);
	    $similar_rooms		= get_post_meta( get_the_id(),'wfcolosseum_similar_rooms',true);
	    $breakfast_info		= get_post_meta( get_the_id(),'wfcolosseum_breakfast_info',true);
	    $room_size			= get_post_meta( get_the_id(),'wfcolosseum_room_size',true);
	    $max_people			= get_post_meta( get_the_id(),'wfcolosseum_max_people',true);
	    $facilities			= get_post_meta( get_the_id(),'wfcolosseum_facilities',true);
	    $rating_title		= get_post_meta( get_the_id(),'wfcolosseum_rating_title',true);
	    $rating_subTitle	= get_post_meta( get_the_id(),'wfcolosseum_rating_subTitle',true);
	    $overall_rating		= get_post_meta( get_the_id(),'wfcolosseum_overall_rating',true);
	    $cleanliness_rating	= get_post_meta( get_the_id(),'wfcolosseum_cleanliness_rating',true);
	    $value_rating		= get_post_meta( get_the_id(),'wfcolosseum_value_rating',true);
	    $view_rating		= get_post_meta( get_the_id(),'wfcolosseum_view_rating',true);
	    $services_rating	= get_post_meta( get_the_id(),'wfcolosseum_services_rating',true);
	    $services			= get_post_meta( get_the_id(),'wfcolosseum_services',false);
	?>
	<div class="inner-container container">
		<div class="l-sec col-md-8">
			<div class="content">
				<div class="room-title">
					<h2><?php the_title(); ?></h2>
				</div>
			</div>
			<?php if( !empty( $room_price ) ){ ?>
			<div class="sub-title">
				Starting from :
				<span><?php echo __($room_price,'wfcolosseum'); ?></span>				
			</div>
			<?php } ?>
			<div class="amenities">
				<ul class="list-inline clearfix">
					<?php if( !empty( $breakfast_info ) ){ ?>
					<li class="col-md-6">
						<div class="title">Breakfast :</div>
						<div class="value"><?php echo __($breakfast_info,'wfcolosseum'); ?></div>
					</li>
					<?php } if( !empty( $room_size ) ){ ?>
					<li class="col-md-6">
						<div class="title">Room Size :</div>
						<div class="value"><?php echo __($room_size,'wfcolosseum'); ?></div>
					</li>
					<?php } if( !empty( $max_people ) ){ ?>
					<li class="col-md-6">
						<div class="title">Max People :</div>
						<div class="value"><?php echo __($max_people,'wfcolosseum'); ?></div>
					</li>
					<?php } if( !empty( $facilities ) ){ ?>
					<li class="col-md-12">
						<div class="title">Facilities :</div>
						<div class="value"><?php echo __($facilities,'wfcolosseum'); ?></div>
					</li>
					<?php } ?>
				</ul>
			</div>
			<div class="icons-container">
				<ul class="list-inline">
					<?php foreach( $services as $service ): ?>
					<li><i class="ravis-icon-<?php echo $service; ?>"></i></li>
					<?php endforeach; ?>
				</ul>
			</div>
			<div class="description">
				<?php the_content(); ?>
			</div>
		</div>
		<div class="r-sec col-md-4">
			<?php echo do_shortcode( $theme_options['booking_form'] ); ?>
			<div class="room-rating">
				<div class="ravis-title-t-2">
					<?php if( !empty( $rating_title ) ){ ?>
					<div class="title"><span><?php echo __($rating_title,'wfcolosseum'); ?></span></div>
					<?php } if( !empty( $rating_subTitle ) ){ ?>
					<div class="sub-title"><?php echo __($rating_subTitle,'wfcolosseum'); ?></div>
					<?php } ?>
				</div>

				<div class="rate-box-container">
					<?php if( !empty( $overall_rating ) ){ ?>
					<div class="rate-box">
						<div class="title">Overall</div>
						<div class="progress">
							<div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $overall_rating; ?>" aria-valuemin="0"
								 aria-valuemax="100" style="width:<?php echo $overall_rating; ?>%"><span><?php echo $overall_rating; ?>%</span></div>
						</div>
					</div>
					<?php } if( !empty( $cleanliness_rating ) ){ ?>
					<div class="rate-box">
						<div class="title">Cleanliness</div>
						<div class="progress">
							<div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $cleanliness_rating; ?>" aria-valuemin="0"
								 aria-valuemax="100" style="width: <?php echo $cleanliness_rating; ?>%"><span><?php echo $cleanliness_rating; ?>%</span></div>
						</div>
					</div>
					<?php } if( !empty( $value_rating ) ){ ?>
					<div class="rate-box">
						<div class="title">Value</div>
						<div class="progress">
							<div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $value_rating; ?>" aria-valuemin="0"
								 aria-valuemax="100" style="width: <?php echo $value_rating; ?>%"><span><?php echo $value_rating; ?>%</span></div>
						</div>
					</div>
					<?php } if( !empty( $view_rating ) ){ ?>
					<div class="rate-box">
						<div class="title">View</div>
						<div class="progress">
							<div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $view_rating; ?>" aria-valuemin="0"
								 aria-valuemax="100" style="width: <?php echo $view_rating; ?>%"><span><?php echo $view_rating; ?>%</span></div>
						</div>
					</div>
					<?php } if( !empty( $services_rating ) ){ ?>
					<div class="rate-box">
						<div class="title">Services</div>
						<div class="progress">
							<div class="progress-bar" role="progressbar" aria-valuenow="<?php echo $services_rating; ?>" aria-valuemin="0"
								 aria-valuemax="100" style="width: <?php echo $services_rating; ?>%"><span><?php echo $services_rating; ?>%</span></div>
						</div>
					</div>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
	<?php endwhile; endif; ?>
</section>
<?php if( !empty( $similar_rooms ) ) { ?>
<section id="other-rooms">
	<div class="inner-container container">
		<div class="ravis-title">
			<div class="inner-box">
				<div class="title"><?php echo __($theme_options['room_similar_title'],'wfcolosseum'); ?></div>
				<div class="sub-title"><?php echo __($theme_options['room_similar_subTitle'],'wfcolosseum'); ?></div>
			</div>
		</div>
		<div class="room-container clearfix">
		<?php $similar_rooms = explode(',',$similar_rooms);
			foreach( $similar_rooms as $similar_room ):
				$args = array( 
						'post_type' => 'rooms', 
						//'s' 		=> $similar_room,
						'name' 		=> $similar_room,
						//'tag__in'    => $similar_room,
						//'post__not_in' => array($post->ID),
						);
				$loop = new WP_Query( $args );
				if ( $loop->have_posts() ): 
				  while ( $loop->have_posts() ) {
					$loop->the_post(); 
					get_template_part( "template-parts/similar","posts" );
				} endif; 
			endforeach;
		?>
		</div>
	</div>
</section>
<?php } get_footer(); ?>