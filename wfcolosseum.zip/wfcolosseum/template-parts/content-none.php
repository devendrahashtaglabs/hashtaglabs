<?php
/**
 * The Page for our theme.
 *
 * Displays all of the section
 *
 * @package WordPress
 * @subpackage wfcolosseum
 * @since wfcolosseum 1.0.0
 *
 */
?>
<?php global $theme_options; ?>
<div class="blog-info">
	<div class="blog-title">
		<h1 class="page-title"><?php _e( 'Nothing Found', 'wfcolosseum' ); ?></h1>
	</div>
	<div class="blog-desc">
		<?php if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>

			<p><?php printf( __( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'wfcolosseum' ), esc_url( admin_url( 'post-new.php' ) ) ); ?></p>

		<?php elseif ( is_search() ) : ?>

			<p><?php _e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'wfcolosseum' ); ?></p>

		<?php else : ?>

			<p><?php _e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'wfcolosseum' ); ?></p>
		<?php endif; ?>
	</div>
</div>