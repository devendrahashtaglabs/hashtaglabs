<?php
/**
 * The Page for our theme.
 *
 * Displays all of the section
 *
 * @package WordPress
 * @subpackage wfcolosseum
 * @since wfcolosseum 1.0.0
 *
 */
?>
<?php global $theme_options; ?>
<?php $date   = get_post_meta( get_the_id(),'wfcolosseum_scheduled_post',true); ?>
<div class="content">
	<div class="date-box">
		<div class="inner-box">
			Date : <span><?php echo date( "Y M d" , strtotime( $date ) ); ?>th</span>
		</div>
	</div>
	<?php the_content(); ?>
</div>
<?php comments_template(); ?>