<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package wfcolosseum
 */
?>
<?php global $theme_options;?>
<?php if( has_post_thumbnail() ): 
 $room_price  = get_post_meta( get_the_id(),'wfcolosseum_room_price',true); 
 $sub_title   = get_post_meta( get_the_id(),'wfcolosseum_sub_title',true); 
?>
<div class="room-box col-xs-6 col-md-4 animated-box" data-animation="fadeInUp">
	<div class="inner-box" data-bg-img="<?php the_post_thumbnail_url(); ?>">
		<a href="<?php the_permalink(); ?>" class="more-info"></a>
		<div class="caption">
			<div class="title"><?php the_title(); ?></div>
			<div class="price">
			<?php if( !empty( $room_price ) ){ ?>
				<div class="title">Starting from :</div>
				<div class="value"><?php echo __($room_price,'wfcolosseum'); ?></div>
			<?php } else { ?>
				<div class="title"><?php echo __($sub_title,'wfcolosseum'); ?></div>
			<?php } ?>
			</div>
			<div class="desc">
				<div class="inner-box">
					<?php echo substr(get_the_excerpt(), 0,50)."…"; ?>
				</div>
			</div>
		</div>

	</div>
</div>
<?php endif; ?>