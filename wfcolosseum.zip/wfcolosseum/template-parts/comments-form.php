<?php
$fields = array(
		'author' => '<div class="form-group"><input class="form-control" id="author" name="author" type="text" required placeholder="Your name*" value="" size="30"/></div>',
	
        'email' => '<div class="form-group"><input class="form-control" id="email" placeholder="Your email*" name="email" type="email" value="" size="30" required /></div>',
	
        'url' => '<div class="form-group"><input class="form-control" id="url" placeholder="Website url*" name="url" type="url" value="" size="30" required /></div>'
    );
$comments_args = array(
    'label_submit' => __( 'Send', 'wfcolosseum' ),
	'class_submit' => 'btn btn-info',
    'title_reply' => __( 'Write a Reply or Comment', 'wfcolosseum' ),
	'fields' => apply_filters( 'comment_form_default_fields', $fields ),
	'comment_field' => '<div class="form-group"><textarea id="comment" name="comment" class="form-control" required cols="40" rows="3" placeholder="Your comments*"></textarea></div>'
	);
comment_form($comments_args); 
?>
