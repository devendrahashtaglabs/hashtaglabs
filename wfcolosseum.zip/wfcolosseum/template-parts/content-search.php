<?php
/**
 * The Page for our theme.
 *
 * Displays all of the section
 *
 * @package WordPress
 * @subpackage wfcolosseum
 * @since wfcolosseum 1.0.0
 *
 */
?>
<?php global $theme_options; ?>
<div class="post-outer-box col-md-6">
	<div class="post-box">
		<?php if( has_post_thumbnail() ): ?>
		<a class="post-img-box" href="<?php the_permalink(); ?>">
			<img src="<?php the_post_thumbnail_url(); ?>"
				 alt="<?php the_title(); ?>" class="post-img img-responsive center-block">
		</a>
		<?php endif; ?>
		<div class="post-b-sec">
			<div class="post-title-box">
				<a href="blog-details.html" class="post-title"><?php the_title(); ?></a>
			</div>
			<div class="post-desc">
				<?php echo get_the_excerpt(); ?>
			</div>
			<div class="read-more-container">
				<a href="<?php the_permalink(); ?>" class="btn btn-default read-more">Read More</a>
			</div>
		</div>
	</div>
</div>