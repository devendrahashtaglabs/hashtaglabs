<?php
/**
 * The inner template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package wfcolosseum
 */
 global $theme_options;
 if ( is_home() ) {
 $page     = get_option( 'page_for_posts' );
 }
 $pageId   = ( !empty( $page ) )?$page:get_the_ID();
 $bannerId = get_post_meta( $pageId, 'wfcolosseum_banner', true );
 $banner   = wp_get_attachment_url( $bannerId );
 $title    = get_post_meta( $pageId, 'wfcolosseum_title', true );
 if( !empty( $title ) ):
?>
<section id="breadcrumb-section" data-bg-img="<?php echo $banner; ?>">
	<div class="inner-container container">
		<div class="ravis-title">
			<div class="inner-box">
				<div class="title">
					<?php echo $title; ?>
				</div>
				<div class="sub-title">
					<?php echo get_post_meta( $pageId, 'wfcolosseum_sub_title', true ); ?>
				</div>
			</div>
		</div>
		<div class="breadcrumb">
			<ul class="list-inline">
				<li><a href="<?php echo home_url("/"); ?>">Home</a></li>
				<li class="current">
					<a href="<?php the_permalink(); ?>">
						<?php echo $title; ?>
					</a>
				</li>
			</ul>
		</div>
	</div>
</section>
<?php endif; ?>