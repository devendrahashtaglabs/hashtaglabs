<?php
/**
 * The inner template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package wfcolosseum
 */
?>
<?php global $theme_options; ?>
<section id="special-offers">
	<div class="inner-container container">
		<div class="ravis-title">
			<div class="inner-box">
				<div class="title">
					<?php echo __($theme_options['offersTitle'],'wfcolosseum');?>
				</div>
				<div class="sub-title">
					<?php echo __($theme_options['offers_subTitle'],'wfcolosseum');?>
				</div>
			</div>
		</div>
		<div class="packages-container clearfix">
			<?php $latest_posts = get_terms( 'offersType' );
 				if ( $latest_posts ) { 
					foreach ( $latest_posts as $post ) {
					$album_image   = get_term_meta( $post->term_id,'album_image',true);
	 				$sub_title	   = get_term_meta( $post->term_id,'offers_sub_title',true);
	 				$price		   = get_term_meta( $post->term_id,'offers_price',true);
	 				$duration	   = get_term_meta( $post->term_id,'offers_duration',true);
	 				$services	   = get_term_meta( $post->term_id,'wf_',true);
			?>
			<div class="package-box col-sm-6 col-md-4">
				<div class="main-inner-box" data-bg-img="<?php echo ( !empty( $album_image ) )?$album_image['url']:''; ?>">
					<div class="title-box">
						<div class="title"><?php echo __($post->name,'wfcolosseum'); ?></div>
						<div class="sub-title"><?php echo __($sub_title,'wfcolosseum'); ?></div>
					</div>
					<div class="price-box">
						<div class="price"><?php echo __($price,'wfcolosseum'); ?></div>
						<div class="type"><?php echo __($duration,'wfcolosseum'); ?></div>
					</div>
					<div class="detail-box">
						<ul>
							<?php foreach( $services as $service ): ?>
							<li>
								<div class="inner-box">
									<?php echo __($service['services'],'wfcolosseum'); ?>
								</div>
							</li>
							<?php endforeach; ?>
						</ul>
					</div>
					<a href="#" class="ravis-btn btn-type-2">Select</a>
				</div>
			</div>
			<?php } } ?>
		</div>
	</div>
</section>