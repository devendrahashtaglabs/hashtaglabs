<?php
/**
 * The inner template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package wfcolosseum
 */
 global $theme_options; 
?>
<section id="video-tour" data-bg-img="<?php echo $theme_options['video_banner']['url']; ?>">
	<div class="inner-container container">
		<div class="row">
			<div class="l-sec col-md-6">
				<div class="ravis-title">
					<div class="inner-box">
						<div class="title">
							<?php echo __($theme_options['video_title'],'wfcolosseum');?>
						</div>
						<div class="sub-title">
							<?php echo __($theme_options['video_subTitle'],'wfcolosseum');?>
						</div>
					</div>
				</div>

			</div>
			<div class="r-sec col-md-6">
				<?php echo __($theme_options['video_description'],'wfcolosseum');?>
			</div>
		</div>
		<div class="row btn-box">
			<a href="<?php echo $theme_options['video_url']; ?>" class="play-btn video-url">
				<i class="fa fa-play"></i>
			</a>
		</div>
	</div>
</section>