<?php
/**
 * The inner template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package wfcolosseum
 */
 global $theme_options;
 $banner   	= $theme_options['404_banner']['url'];
 $title    	= $theme_options['banner_title'];
 $sub_title = $theme_options['banner_subTitle'];
?>
<section id="breadcrumb-section" class="not-found" data-bg-img="<?php echo $banner; ?>">
	<div class="inner-container container">
		<div class="ravis-title">
			<div class="inner-box">
				<div class="title"><?php echo __($title,'vrijzinnig');?></div>
				<div class="sub-title"><?php echo __($sub_title,'vrijzinnig');?></div>
			</div>
		</div>
		<div class="not-found-container">
			<div class="desc">Would you like to go to <a href="<?php echo home_url("/"); ?>">homepage</a> instead?</div>
			<!-- Search Box -->
			<div class="search-box">
				<?php get_search_form(); ?>
			</div>
		</div>
		<div class="breadcrumb">
			<ul class="list-inline">
				<li><a href="<?php echo home_url("/"); ?>">Home</a></li>
				<li class="current">
					<a href="<?php the_permalink(); ?>">
						<?php echo __($title,'vrijzinnig');?>
					</a>
				</li>
			</ul>
		</div>
	</div>
</section>