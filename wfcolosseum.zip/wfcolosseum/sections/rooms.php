<?php
/**
 * The inner template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package wfcolosseum
 */
 global $theme_options; 
 $args = array( 'number'=>'4' );
 $latest_posts = get_terms( 'roomsType', $args );
 if ( $latest_posts ) { 
?>
<section id="luxury-rooms" class="clearfix">
	<?php  foreach ( $latest_posts as $post ): 
	 $album_image = get_term_meta( $post->term_id,'album_image',true);
	 $sub_title   = get_term_meta( $post->term_id,'cat_sub_title',true);
	?>
	<div class="room-boxes col-sm-6 col-md-3">
		<a href="<?php echo home_url('/wfrooms/').$post->slug; ?>" class="inner-container" data-bg="<?php echo ( !empty( $album_image ) )?$album_image['url']:''; ?>">
			<span class="ravis-title">
				<span class="inner-box">
					<span class="title"><?php echo __($post->name,'wfcolosseum'); ?></span>
					<span class="sub-title"><?php echo __($sub_title,'wfcolosseum'); ?></span>
				</span>
			</span>
		</a>
	</div>
	<?php endforeach; wp_reset_query(); ?>
</section>
<?php } ?>