<?php
/**
 * The inner template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package wfcolosseum
 */
?>
<?php global $theme_options; ?>
<div class="slider-available-sec">
	<!-- Main Slider -->
	<section id="main-slider">
		<?php foreach( $theme_options['opt-slides'] as $slides ): ?>
		<div class="items">
			<div class="img-container" data-bg-img="<?php echo $slides['image']; ?>"></div>
			<!-- Change the URL section based on your image\'s name -->
			<div class="slide-caption">
				<div class="inner-container clearfix">
					<div class="up-sec"><?php echo __($slides['title'],'wfcolosseum');?></div>
					<div class="down-sec"><?php echo __($slides['description'],'wfcolosseum');?></div>
				</div>
			</div>
		</div>
		<?php endforeach; ?>
	</section>
</div>
	<!-- End of Main Slider -->