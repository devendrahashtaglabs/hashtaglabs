<?php
/**
 * The inner template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package wfcolosseum
 */
?>
<?php global $theme_options; ?>
<?php $paged 		  = (get_query_var('paged')) ? get_query_var('paged') : 1; ?>
<section id="gallery">
	<div class="inner-container container">
		<!-- Gallery Container -->
		<div class="gallery-container">
			<div class="sort-section">
				<div class="sort-section-container">
					<div class="sort-handle">Filters</div>
					<ul class="list-inline">
						<?php $terms = get_terms( array(
													'taxonomy' => 'GalleryType',
													'hide_empty' => false,
												) ); ?>
						<li><a href="#" data-filter="*" class="active">All</a></li>
						<?php foreach( $terms as $term ) : ?>
						<li><a href="#" data-filter=".<?php echo strtolower( $term->name ); ?>"><?php echo $term->name; ?></a></li>
						<?php endforeach; ?>
					</ul>
				</div>
			</div>
			<ul class="image-main-box clearfix">
			<?php $args = array( 
							'post_type' 	 => 'gallery', 
							'posts_per_page' => get_option('posts_per_page'),
							'paged'          => $paged, 
							);
				$loop = new WP_Query( $args );
				while ( $loop->have_posts() ) : $loop->the_post(); 
				if ( has_post_thumbnail() ) : 
				$categories = get_the_terms( get_the_ID(), 'GalleryType' );
				$terms	 = array();
				foreach( $categories as $category ):
				$terms[] = $category->name;
				endforeach;
				$term = implode( " ", $terms );
			 ?>
				<li class="item col-xs-6 col-md-4 <?php echo strtolower( $term );  ?>">
					<figure>
						<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>"/>
						<a href="<?php the_post_thumbnail_url(); ?>" class="more-details"
						   data-title="<?php the_title(); ?>">Enlarge</a>
						<figcaption>
							<h4><?php the_title(); ?></h4>
						</figcaption>
					</figure>
				</li>
			<?php endif; endwhile; ?>
			</ul>
			<?php if ( is_page('gallery') ) {
				if ( function_exists('wp_bootstrap_pagination') ) :
						 wp_bootstrap_pagination(array('custom_query' => $loop));
			    endif;
			} else { ?>
			<a href="<?php echo home_url("/gallery/"); ?>" class="gallery-more-btn ravis-btn btn-type-2">More ...</a>
			<?php } wp_reset_query(); ?>
		</div>
	</div>
</section>