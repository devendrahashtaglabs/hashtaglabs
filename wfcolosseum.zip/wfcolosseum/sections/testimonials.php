<?php
/**
 * The inner template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package wfcolosseum
 */
?>
<?php global $theme_options; ?>
<style>
#testimonials-section {
	background: url("<?php echo $theme_options['testimonials_banner']['url'] ; ?>") center no-repeat;
}
</style>
<section id="testimonials-section" data-parallax="scroll" data-image-src="<?php echo $theme_options['testimonials_banner']['url'] ; ?>">
	<div class="inner-container container">
		<div class="owl-carousel owl-theme">
			<?php foreach( $theme_options['testimonial-slides'] as $slide ): ?>
			<div class="item">
				<div class="guest">
					<div class="ravis-title">
						<div class="inner-box">
							<div class="title"><?php echo __($slide['title'],'wfcolosseum');?></div>
							<div class="sub-title"><?php echo __($slide['url'],'wfcolosseum');?></div>
						</div>
					</div>
				</div>
				<div class="text">
					<?php echo __($slide['description'],'wfcolosseum');?>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>