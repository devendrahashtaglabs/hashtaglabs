<?php
/**
 * The inner template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package wfcolosseum
 */
?>
<?php global $theme_options; ?>
<div class="slider-available-sec">
	<section id="main-availability-form">
		<div class="inner-container container">
			<div class="l-sec col-md-4">
				<div class="ravis-title">
					<div class="inner-box">
						<div class="title">Find a Room</div>
						<div class="sub-title">When you want to be our guest?</div>
					</div>
				</div>
			</div>
			<div class="r-sec col-md-8">
				<form class="booking-form clearfix" action="#"><!-- Do Not remove the classes -->
					<div class="col-md-10">
						<div class="input-daterange row">
							<div class="booking-fields col-md-6">
								<input placeholder="Check in" class="datepicker-fields check-in" type="text"
									   name="start"/>
								<!-- Date Picker field ( Do Not remove the "datepicker-fields" class ) -->
								<i class="fa fa-calendar"></i><!-- Date Picker Icon -->
							</div>
							<div class="booking-fields col-md-6">
								<input placeholder="Check out" class="datepicker-fields check-out" type="text"
									   name="end"/>
								<i class="fa fa-calendar"></i>
							</div>
						</div>
						<div class="row">
							<div class="booking-fields col-md-6">
								<!-- Select boxes ( you can change the items and its value based on your project's needs ) -->
								<select name="room-type">
									<option value="">Adult</option>
									<!-- Select box items ( you can change the items and its value based on your project's needs ) -->
									<option value="2">1</option>
									<option value="3">2</option>
									<option value="4">3</option>
									<option value="5">4</option>
									<option value="6">5</option>
								</select>
								<!-- End of Select boxes -->
							</div>
							<div class="booking-fields col-md-6">
								<select name="guest">
									<option value="">Child</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
								</select>
							</div>
						</div>
					</div>
					<div class="col-md-2">
						<button type="submit" class="ravis-btn btn-type-1">
							<span class="inner-box">
								Book Now
							</span>
						</button>
					</div>
				</form>

			</div>
		</div>
	</section>
	<!--End of Main Booking form-->
</div>