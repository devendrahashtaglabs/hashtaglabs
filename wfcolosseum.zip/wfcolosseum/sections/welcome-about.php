<?php
/**
 * The inner template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package wfcolosseum
 */
?>
<?php global $theme_options; ?>
<section id="welcome-section" class="has-user">
	<div class="inner-container container">
		<?php if(have_posts()): while(have_posts()):the_post(); ?>
		<div class="l-sec col-md-7">
			<div class="ravis-title-t-1">
				<div class="title"><span><?php echo get_post_meta( get_the_ID(), 'wfcolosseum_title', true ); ?></span></div>
				<div class="sub-title"><?php echo get_post_meta( get_the_ID(), 'wfcolosseum_sub_title', true ); ?></div>
			</div>
			<div class="content">
				<?php echo get_the_excerpt(); ?>
			</div>
			<cite>Chris Coleman - General Manager</cite>
		</div>
		<?php if ( has_post_thumbnail() ) : ?>
		<div class="r-sec col-md-5">
			<div class="user-img-box">
				<div class="inner-box">
					<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>">
				</div>
			</div>
		</div>
		<?php endif; endwhile; endif; ?>
	</div>
</section>