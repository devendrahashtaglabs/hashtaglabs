<?php 
if ( have_comments() ) : ?>
	<!-- .comment-list -->
	<ol class="comment-list">
    <?php
       wp_list_comments('type=comment&callback=wfcolosseum_comment');
    ?>
	</ol>
	<?php //comment_form(); ?>
	<?php  /** Are there comments to navigate through **/ ?>
	<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : ?>
	<!-- .comment-navigation -->
	<nav class="navigation comment-navigation" role="navigation">
    	<h1 class="screen-reader-text section-heading"><?php _e( 'Comment navigation', 'lutheran' ); ?></h1>
    	<div class="nav-previous"><?php previous_comments_link( __( '&larr; Older Comments', 'lutheran' ) ); ?></div>
   		<div class="nav-next"><?php next_comments_link( __( 'Newer Comments &rarr;', 'lutheran' ) ); ?></div>
	</nav>
	<?php endif; // Check for comment navigation ? ?>
<?php endif; // have_comments() ?>
<div class="comments-form">
<?php get_template_part( "template-parts/comments","form" ); ?>
</div>